export const mockTags = [
    {
        id: "1",
        name: 'מתוקים'
    },
    {
        id: "2",
        name: 'פירות'
    },
    {
        id: "3",
        name: 'ירקות'
    },
    {
        id: "4",
        name: 'מבצע'
    },
    {
        id: "5",
        name: 'שימורים'
    },
    {
        id: "6",
        name: 'מוצרי חלב'
    },
    {
        id: "7",
        name: 'מדריך להזמנה'
    },
    {
        id: "8",
        name: 'עוגות'
    }
];