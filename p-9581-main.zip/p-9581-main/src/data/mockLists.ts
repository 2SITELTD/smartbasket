
export const mockLists = [
    {    
        id:"1739858368584",
        title:"רשימה 1",
        description:"רשימת ניסיון",
        icon:"default-icon",
        products:[
            {productId:"3", quantity:2},
            {productId:"5", quantity:1},
            {productId:"7" , quantity:3},
            {productId:"11", quantity:4},
            {productId:"15", quantity:5},
            {productId:"17", quantity:6}
        ]
    },
    {    
        id:"1739858368585",
        title:"רשימה 2",
        description:"2 רשימת ניסיון",
        icon:"default-icon",
        products:[
            {productId:"1", quantity:2},
            {productId:"15", quantity:1},
            {productId:"17" , quantity:3},
        ]
    },
    {    
        id:"1739858368586",
        title:"רשימה 3",
        description:"3 רשימת ניסיון",
        icon:"default-icon",
        products:[
            {productId:"8", quantity:2},            
            {productId:"9", quantity:1},    
            {productId:"10", quantity:3},
            {productId:"17", quantity:4}
        ]
    }

]
