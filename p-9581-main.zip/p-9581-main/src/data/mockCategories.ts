export const mockCategories = [
    {
        id: '1',
        name: 'פירות וירקות',
        icon: 'https://pub-e320cbb58ef047df8774a8d4068ef39f.r2.dev/veg.png'
    },
    {
        id: '2',
        name:'חטיפים ושימורים',
        icon: 'https://pub-e320cbb58ef047df8774a8d4068ef39f.r2.dev/honey.png'
    },
    {
        id: '3',
        name:'דגנים ופסטה',
        icon: 'https://pub-e320cbb58ef047df8774a8d4068ef39f.r2.dev/wheat.png'
    },
    {
        id: '4',
        name: 'קפה ותה',
        icon: 'https://pub-e320cbb58ef047df8774a8d4068ef39f.r2.dev/seeds.png'
    }, 
    {
        id: '5',
        name: 'תבלינים',
        icon: 'https://pub-e320cbb58ef047df8774a8d4068ef39f.r2.dev/veg.png'
    },
    {
        id: '6',
        name:'שמנים ורטבים',
        icon: 'https://pub-e320cbb58ef047df8774a8d4068ef39f.r2.dev/honey.png'
    },
    {
        id: '7',
        name:'מאפיהקמח וממתקים',
        icon: 'https://pub-e320cbb58ef047df8774a8d4068ef39f.r2.dev/wheat.png'
    },
    {
        id: '8',
        name: 'מוצרי מזון',
        icon: 'https://pub-e320cbb58ef047df8774a8d4068ef39f.r2.dev/seeds.png'
    },
    {
        id: '9',
        name: 'מועדפים',
        icon: 'https://pub-e320cbb58ef047df8774a8d4068ef39f.r2.dev/seeds.png'
    },  
];