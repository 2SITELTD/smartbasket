export const mockCartItems = [
    {
        id: "1",
        name: "ערגליות",
        price: 12.9,
        originalPrice: 18.9,
        image: "https://pub-e320cbb58ef047df8774a8d4068ef39f.r2.dev/argaliot.png",
        quantity: 2 
    },
    {
        id: "2",
        name: "חלב",
        price: 8.9,
        originalPrice: null,
        image: "https://pub-e320cbb58ef047df8774a8d4068ef39f.r2.dev/milk.png",
        quantity: 1 
    }
];
