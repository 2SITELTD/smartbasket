import React from 'react';
import { EditButton } from '../userArea/EditButton';

const AddressCard: React.FC = () => {
  return (
    <div className="w-full">
      Address Card Content Here
    </div>
  );
};

export default AddressCard;
